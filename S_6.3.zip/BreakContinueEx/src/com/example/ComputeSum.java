package com.example;

import java.util.Scanner;

public class ComputeSum {

    public static void main(String[] args) {
        Scanner xd = new Scanner(System.in);
        int num=10, input=0, sum=0, stop=0;
        System.out.println("ingresa los numeros: para salir presione 0");
        for(int i=0; i<10;i++)
        {
            input =xd.nextInt();
            if(input==0)
            {
                break;
                     
            }
            else
            {
                sum+=input;
            }
           
        }
        System.out.println("la suma de los numeros es: " + sum);
        

       

    }
}

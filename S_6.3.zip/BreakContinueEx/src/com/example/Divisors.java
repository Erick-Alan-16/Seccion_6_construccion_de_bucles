package com.example;

import java.util.Scanner;

public class Divisors {

    public static void main(String args[]) {

        
         Scanner console = new Scanner(System.in);
         
        System.out.print("Enter the number :  ");// el usuario ingresa un numero
        int num = console.nextInt();//declaracion de la varibale num
         
     System.out.print("Divisors of " + num+" "+ "="+" " );
//este ciclo de ejecuta dependiendo del valor ingresado del usuario
        for (int i = 1; i <= num; i++) {
            if (num % i != 0) { //si el modulo de la division es 0 se imprime i 
                continue;
            }
            System.out.print(i + " , ");//se imprimen los numeros que acreditan la condicion
        }
    }
}
